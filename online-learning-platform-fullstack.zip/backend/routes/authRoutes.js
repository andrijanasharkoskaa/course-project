
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const pool = require('../config/database');
const router = express.Router();

router.post('/register', async (req, res) => {
  const { name, email, password, role } = req.body;
  const hashed = await bcrypt.hash(password, 10);
  await pool.query(
    'INSERT INTO users(name,email,password,role) VALUES($1,$2,$3,$4)',
    [name,email,hashed,role]
  );
  res.json({ message: "User registered" });
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const result = await pool.query('SELECT * FROM users WHERE email=$1',[email]);
  if(result.rows.length===0) return res.status(400).send("User not found");
  const user = result.rows[0];
  const match = await bcrypt.compare(password,user.password);
  if(!match) return res.status(400).send("Invalid password");
  const token = jwt.sign({id:user.id, role:user.role}, process.env.JWT_SECRET);
  res.json({ token });
});

module.exports = router;
