
const express = require('express');
const pool = require('../config/database');
const router = express.Router();

router.post('/upload/:courseId', async (req,res)=>{
  const { title, content } = req.body;
  await pool.query(
    "INSERT INTO lessons(course_id,title,content) VALUES($1,$2,$3)",
    [req.params.courseId,title,content]
  );
  res.json({message:"Lesson uploaded"});
});

module.exports = router;
