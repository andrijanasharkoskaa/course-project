
const express = require('express');
const pool = require('../config/database');
const router = express.Router();

router.get('/', async (req,res)=>{
  const result = await pool.query("SELECT * FROM courses WHERE status='PUBLISHED'");
  res.json(result.rows);
});

router.patch('/:id/publish', async (req,res)=>{
  await pool.query("UPDATE courses SET status='PUBLISHED' WHERE id=$1",[req.params.id]);
  res.json({message:"Course published"});
});

module.exports = router;
