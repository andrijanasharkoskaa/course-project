
import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [courses,setCourses] = useState([]);

  const fetchCourses = async () => {
    const res = await axios.get('http://localhost:5000/api/courses');
    setCourses(res.data);
  };

  return (
    <div>
      <h1>Online Learning Platform</h1>
      <button onClick={fetchCourses}>Load Courses</button>
      <ul>
        {courses.map(c => <li key={c.id}>{c.title}</li>)}
      </ul>
    </div>
  );
}

export default App;
